export async function onRequestGet({ env }) {
  if (!env.MEDIA) return Response.json({ categories: {} });
  const categories = {};
  let cursor;
  do {
    const page = await env.MEDIA.list({ prefix: 'portfolio/', cursor, limit: 1000 });
    for (const obj of page.objects) {
      const rest = obj.key.slice('portfolio/'.length);
      const slash = rest.indexOf('/');
      if (slash < 1) continue;
      const category = rest.slice(0, slash);
      (categories[category] ||= []).push(obj.key);
    }
    cursor = page.truncated ? page.cursor : undefined;
  } while (cursor);
  Object.values(categories).forEach(list => list.sort());
  return Response.json({ categories }, { headers: { 'Cache-Control':'no-store' } });
}
