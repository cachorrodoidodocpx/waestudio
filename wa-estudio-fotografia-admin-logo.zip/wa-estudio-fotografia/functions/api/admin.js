const COOKIE='wa_admin_session';
const MAX=15*1024*1024;
const TYPES=new Set(['image/jpeg','image/png','image/webp']);
const CATS=new Set(['casamento','gestante','bebe-reborn','infantil','familia','ensaios','natal','datas-especiais']);
const enc = new TextEncoder();
function b64(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');}
function unb64(s){s=s.replaceAll('-','+').replaceAll('_','/');while(s.length%4)s+='=';return Uint8Array.from(atob(s),c=>c.charCodeAt(0));}
async function hmac(secret,payload){const k=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',k,enc.encode(payload)));}
async function session(secret){const p=`${Date.now()}.${crypto.randomUUID()}`;return `${b64(enc.encode(p))}.${b64(await hmac(secret,p))}`;}
async function valid(request,secret){if(!secret)return false;const raw=request.headers.get('Cookie')||'';const c=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='));if(!c)return false;const token=c.slice(COOKIE.length+1).split('.');if(token.length!==2)return false;let p;try{p=new TextDecoder().decode(unb64(token[0]));}catch{return false;}const ts=Number(p.split('.')[0]);if(!Number.isFinite(ts)||Date.now()-ts>7*24*60*60*1000)return false;const exp=await hmac(secret,p);let act;try{act=unb64(token[1]);}catch{return false;}if(exp.length!==act.length)return false;let d=0;for(let i=0;i<exp.length;i++)d|=exp[i]^act[i];return d===0;}
function headers(cookie){return {'Content-Type':'application/json','Set-Cookie':cookie,'Cache-Control':'no-store'};}
export async function onRequestGet({request,env}){
  if(!await valid(request,env.SESSION_SECRET))return Response.json({authenticated:false});
  if(!env.MEDIA)return Response.json({authenticated:true,objects:[],error:'R2 não configurado'},{status:503});
  const page=await env.MEDIA.list({prefix:'portfolio/',limit:1000});
  return Response.json({authenticated:true,objects:page.objects.map(o=>({key:o.key,size:o.size,uploaded:o.uploaded}))});
}
export async function onRequestPost({request,env}){
  if(!env.MEDIA)return Response.json({error:'R2 não configurado no projeto.'},{status:503});
  const ct=request.headers.get('Content-Type')||'';
  if(ct.includes('application/json')){
    const body=await request.json();
    if(body.action==='login'){
      if(!env.ADMIN_PASSWORD||!env.SESSION_SECRET)return Response.json({error:'Configure ADMIN_PASSWORD e SESSION_SECRET no Cloudflare.'},{status:503});
      if(body.password!==env.ADMIN_PASSWORD)return Response.json({error:'Senha incorreta.'},{status:401});
      const t=await session(env.SESSION_SECRET);return new Response(JSON.stringify({ok:true}),{headers:headers(`${COOKIE}=${t}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`)});
    }
    if(body.action==='logout')return new Response(JSON.stringify({ok:true}),{headers:headers(`${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`)});
    if(body.action==='delete'){
      if(!await valid(request,env.SESSION_SECRET))return Response.json({error:'Não autorizado.'},{status:401});
      const key=String(body.key||'');if(!key.startsWith('portfolio/'))return Response.json({error:'Arquivo inválido.'},{status:400});
      await env.MEDIA.delete(key);return Response.json({ok:true});
    }
    return Response.json({error:'Ação inválida.'},{status:400});
  }
  if(!await valid(request,env.SESSION_SECRET))return Response.json({error:'Não autorizado.'},{status:401});
  const form=await request.formData();
  const category=String(form.get('category')||'');
  if(!CATS.has(category))return Response.json({error:'Categoria inválida.'},{status:400});
  const files=form.getAll('photos').filter(v=>v && typeof v.arrayBuffer==='function');
  if(!files.length)return Response.json({error:'Nenhuma imagem enviada.'},{status:400});
  const uploaded=[];
  for(const f of files){
    if(!TYPES.has(f.type)||f.size>MAX)continue;
    const ext=f.type==='image/png'?'png':f.type==='image/webp'?'webp':'jpg';
    const key=`portfolio/${category}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
    await env.MEDIA.put(key,f.stream(),{httpMetadata:{contentType:f.type,cacheControl:'public, max-age=31536000, immutable'}});
    uploaded.push(key);
  }
  return Response.json({ok:true,uploaded});
}
