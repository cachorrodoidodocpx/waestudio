export async function onRequestGet({ env, params }) {
  if (!env.MEDIA) return new Response('R2 não configurado', { status:503 });
  const raw = params.path || '';
  const key = Array.isArray(raw) ? raw.join('/') : raw;
  if (!key.startsWith('portfolio/')) return new Response('Not found', { status:404 });
  const object = await env.MEDIA.get(key);
  if (!object) return new Response('Not found', { status:404 });
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('etag', object.httpEtag);
  headers.set('Cache-Control','public, max-age=31536000, immutable');
  return new Response(object.body, { headers });
}
